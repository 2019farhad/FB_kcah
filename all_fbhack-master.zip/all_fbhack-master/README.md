# all_fbhack
All country fb hack        created by mohammad sultani
COMMANDS.........👇👇👇👇 
  pkg update
2  pkg upgrade
3  pkg install python
4  pkg install python2
5  pkg install git
6  pip2 install requests
7  pip2 install mechanize
8  git clone https://github.com/Mohammadjan1122/all_fbhack
9  cd all_fbhack
10 python2 mohammad_sultani.py
